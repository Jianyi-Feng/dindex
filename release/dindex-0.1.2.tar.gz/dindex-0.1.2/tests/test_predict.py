import json
import numpy as np
import pandas as pd
import pytest
from dindex import fit_calibration, predict_calibration
from dindex.cli import main


def test_saved_calibration_predictions_and_flags(tmp_path):
    x = np.arange(10., 31.)
    data = pd.DataFrame({"temperature": x, "D": np.tanh(.12 * (x - 19))})
    model = json.loads(json.dumps(fit_calibration(data, "temperature")))
    result = predict_calibration(model, pd.DataFrame({"temperature": [15, 19, 35, np.nan]}))
    assert np.allclose(result.D_predicted[:3], np.tanh(.12 * (np.array([15, 19, 35]) - 19)))
    assert list(result.prediction_qc) == ["within_driver_range", "within_driver_range", "extrapolation", "missing_driver"]
    data.to_csv(tmp_path / "train.csv", index=False)
    main(["fit", "--table", str(tmp_path / "train.csv"), "--driver", "temperature", "-o", str(tmp_path / "model.json")])
    main(["predict", "--model", str(tmp_path / "model.json"), "--table", str(tmp_path / "train.csv"), "-o", str(tmp_path / "out.csv")])
    assert np.allclose(pd.read_csv(tmp_path / "out.csv").D_predicted, data.D)


def test_prediction_input_checks_and_endpoint_accounting():
    data = pd.DataFrame({"x": range(7), "D": [-1, -.5, -.2, .2, .5, 1, np.nan]})
    model = fit_calibration(data, "x")
    assert (model["n_fit"], model["n_endpoints_excluded"], model["n_missing"]) == (4, 2, 1)
    with pytest.raises(ValueError):
        fit_calibration(data.assign(D=2), "x")
    with pytest.raises(ValueError):
        fit_calibration(data.assign(x=1), "x")
    with pytest.raises(ValueError):
        predict_calibration(model, pd.DataFrame({"x": [np.inf]}))
    with pytest.raises(ValueError):
        predict_calibration({**model, "schema": "unknown"}, data)
