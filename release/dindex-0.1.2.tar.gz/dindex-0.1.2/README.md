# dindex — a two-group log-ratio index for microbial community tables

`dindex` computes the D-index, a single number that summarizes the balance between two groups of taxa in a sample:

$$D = \frac{P - M}{P + M} = \tanh\!\left(\tfrac{1}{2}\ln\frac{P}{M}\right)$$

- **P** is the summed abundance of the "plus" group.
- **M** is the summed abundance of the "minus" group.

D runs from **−1** (only M detected) through **0** (equal abundance) to **+1** (only P detected).

The index was introduced for marine giant viruses, contrasting Imitervirales (P) with Algavirales (M). Nothing in the
calculation is specific to viruses. It applies to any two groups whose balance you expect to track an environmental gradient.
Examples:

- ecotypes or clades (e.g. *Prochlorococcus* vs *Synechococcus*, SAR11 subclades);
- warm- vs cold-associated lineages;
- copiotrophs vs oligotrophs;
- functional gene families (e.g. two nitrogenase or rhodopsin clades).

The input can be read counts, coverage, TPM, relative abundance or cell counts. Because D uses only the ratio P/M, it is
unchanged by a common multiplicative scaling of P and M within a sample (including conversion to relative abundance). It is
not generally unchanged by rarefaction, which adds sampling variation and can introduce zeros.

## Install

```bash
pip install .                    # from this folder; core needs numpy, pandas, scipy
pip install ".[calibrate]"       # adds statsmodels for calibration helpers
```

For R, run `source("R/dindex.R")`. It uses base R only, with an optional `d_from_phyloseq()` helper.

## Quick start

### Command line

```bash
# abundance: samples x features (first column = sample IDs); taxonomy: feature ID + one column per rank
dindex compute --abundance counts.tsv --taxonomy taxonomy.tsv --rank genus \
               --plus Prochlorococcus --minus Synechococcus --counts --min-share 0.2 -o D.tsv

# join D.tsv with an environment table, then:
dindex calibrate --table D_env.tsv --driver temperature                 # sensitivity + temperature at D = 0
dindex baseline  --table D_dates.tsv --date date --baseline-end 2013-12-31 -o residuals.tsv
```

Several labels can be pooled into one side, e.g. `--plus Imitervirales Pimascovirales`. Use `--features-as rows` when features
are rows. Instead of `--counts`, use `--bootstrap 2000` for coverage or TPM tables.

### Python

```python
import pandas as pd, dindex
from dindex import calibrate

counts = pd.read_csv("counts.tsv", sep="\t", index_col=0)                           # samples x features
tax = pd.read_csv("taxonomy.tsv", sep="\t").set_index("feature")["order"]            # feature -> group
d = dindex.d_from_table(counts, tax, plus="Imitervirales", minus="Algavirales", min_share=0.5)
d[["D", "share", "qc"]]

dindex.d_index(p_abundance, m_abundance)          # vectorized core formula
dindex.d_ci_counts(n_plus_reads, n_minus_reads)   # Beta (Jeffreys) interval for read counts
dindex.d_ci_bootstrap(coverage, tax, "A", "B")    # descriptive feature-composition interval for coverage/TPM

calibrate.sensitivity(df, "temperature", covariates=["size_fraction"], cluster="station")
calibrate.zero_point(df, "temperature", group="station")
calibrate.seasonal_baseline(df, "date", baseline_end="2013-12-31")
```

### R

```r
source("R/dindex.R")
d <- d_from_table(counts, taxonomy_vector, plus = "Imitervirales", minus = "Algavirales", min_share = 0.5)
d_ci_counts(d$plus, d$minus)
d_from_phyloseq(ps, rank = "Order", plus = "Imitervirales", minus = "Algavirales")
d_zero_point(df, "temperature", group = "station")
```

## What the output columns mean

| Column | Meaning |
|---|---|
| `plus`, `minus`, `total` | Summed abundance of P, of M, and of all features mapped in the taxonomy |
| `D` | The index; `NaN` when P + M = 0 |
| `log_ratio` | ln(P/M); ±inf for zeros unless `--pseudocount` is set. D itself never needs a pseudocount |
| `share` | (P + M)/total: how much of the table the index summarizes |
| `qc` | `ok`, `undefined` (P + M = 0), `low_share` or `low_total` |
| `D_lower`, `D_upper` | 95% interval: Beta credible interval for read counts (`--counts`), descriptive feature-composition sensitivity interval otherwise (`--bootstrap`) |
| `n_plus_features`, `n_minus_features` | Number of non-zero features on each side |

## Using D well

1. **Choose the pair before testing it.** A good pair is abundant (high `share`) and responds in opposite directions to the
   gradient of interest. Derive it on one dataset (a time series, say) and test it on independent data.
   `calibrate.screen_pairs()` ranks candidate pairs, but screening many pairs inflates false positives, so treat its output as
   hypotheses.
2. **Read D as change against a local baseline.** In the giant-virus study, D's sensitivity to temperature was similar across
   size fractions and between a coastal time series and the open ocean. Its zero point was not: D = 0 fell between 10 and
   23 °C depending on fraction and system. Report `sensitivity()` and `zero_point()` separately, and compare D within a
   consistent sampling and extraction protocol.
3. **Keep the compositional caveats.** D is a relative measure. It does not give absolute abundance, and extraction or mapping
   biases that differ between the two groups change it.
4. **Handle zeros explicitly.** Samples where one group is absent have D = ±1, which is a valid value. Samples where both are
   absent are undefined. Use `min_total` or `min_share` to flag samples where D rests on very few reads or a minor part of
   the community.
5. **Respect dependence.** Use cluster-robust errors for repeated samples from a station (`cluster=`), autocorrelation-robust
   errors for time series (`hac_lags=`), and year- or event-level inference for anomalies from `seasonal_baseline()`.

See `docs/REPORTING_CHECKLIST.md` for a minimum reporting standard and `docs/METHODS_TEMPLATE.md` for an adaptable Methods
paragraph.

## Examples and tests

- `examples/spot_tara_example.py` reproduces the core giant-virus analyses (D, temperature sensitivity by size fraction,
  zero points, heatwave residuals, Tara station-clustered sensitivity) from the published tables in `examples/data/`.
- `examples/data/toy_*.tsv` is a small count table for trying the CLI with a different taxon pair.
- `pytest` runs the Python tests; `Rscript tests/test_dindex.R` runs the R checks. Both verify that the functions reproduce the
  published SPOT and Tara D values exactly.

## Citation

If you use the D-index, please cite: Feng, J., Hou, S. *et al.* A giant-virus index of warming-associated community
reorganization (in submission).

## License

MIT; see `LICENSE`.


## Standalone release and reviewer quick start

Use the complete source archive to obtain Python, the base-R implementation, examples,
tests and documentation together. The Python wheel contains the Python library and CLI.
Python 3.9 or later is required; R users need base R and can source `R/dindex.R`.
From the extracted source directory:

```bash
python -m pip install ".[calibrate,test]"
python -m pytest tests
Rscript tests/test_dindex.R
python examples/spot_tara_example.py
```

For ordinary use, `python -m pip install .` is sufficient for calculation and prediction;
`.[calibrate]` adds statsmodels for sensitivity, zero-point and seasonal analyses.
Installation downloads dependencies unless they are already available. No raw metagenomes,
private project paths or external data services are required for the supplied examples.
See [the own-data workflow](docs/OWN_DATA_WORKFLOW.md) and
[release instructions](docs/RELEASE.md). This is a reusable index toolkit; reproducing the
paper's projection ensemble (a ridge regression and a random forest), cross-validation and CMIP6 maps requires the study analysis
scripts and their full input data in the accompanying research archive.

## Save a local calibration and predict D

```bash
dindex fit --table examples/data/toy_D_env.tsv --driver temperature -o local_model.json
dindex predict --model local_model.json --table examples/data/toy_environment.tsv -o predictions.tsv
```

The model fits `atanh(D) = intercept + slope * (driver - center)` on the user's
observations and predicts `tanh(...)`, bounded by −1 and +1. It excludes exact D = ±1
rather than inventing a pseudocount, records exclusions in the JSON, and flags driver
values outside the fitted range. Missing drivers produce missing predictions. This
single-driver descriptive calibration gives point predictions without uncertainty
intervals. Validate on independent sites or time periods before interpreting predictions;
a range flag alone does not establish ecological transferability. It predicts D from
the driver, and does not infer temperature from D. The existing `calibrate` command
estimates a different quantity: the linear sensitivity of D itself.
