# Changelog

## 0.1.2

- Documentation only; the Python and R code, the tests and the example data are
  identical to 0.1.1. The manuscript's projection ensemble is now described as a
  ridge regression plus a random forest (it was a 14-model ensemble when 0.1.1 was
  written), and the note on the PolB catalogue reflects that it is now supplied
  with the manuscript.

## 0.1.1

- Add JSON-saveable single-driver log-ratio calibration, bounded predictions and
  driver-range QC through Python and `dindex fit` / `dindex predict`.
- Document own-data analysis, calibration scope and reviewer installation.
- Include R, example data, tests and documentation in the source distribution.
- Correct the manuscript citation to preserve the full title including across scales.

## 0.1.0

- Index calculation, mapped-coverage QC, count intervals, feature bootstrap,
  sensitivity/zero-point calibration, seasonal baselines and Python/R examples.

- Synchronize the SPOT example heatwave-phase metadata with the current local data table; D values are unchanged.
