# Release and scope

Version 0.1.2 is prepared locally for reviewer/community use. Installation from the
source directory or a wheel does not imply a public repository or PyPI release.

Build with `python -m pip install build`, then `python -m build`. The `.tar.gz`
source distribution includes Python, R, tests, documentation and example datasets.
The wheel installs only the Python package and CLI. Run tests and examples from
an extracted source distribution after installing its wheel to check independence
from the development checkout.

Before public release, confirm repository ownership, software citation authorship,
and permission to redistribute the SPOT/Tara derived example tables under the
chosen terms. The existing MIT license applies to software; underlying study data
retain their original terms. Replace the provisional manuscript citation once
published. Attach both distributions, checksums and validation records to a tagged
repository release and a persistent archive. Confirm reviewer/public access and
that the repository also contains the study analysis scripts promised by the
manuscript. A public upload has not been performed by this local build.

The bundled SPOT/Tara tables are derived input fixtures for checking D calculation;
`examples/spot_tara_example.py` demonstrates selected calibration and baseline
analyses. It does not rerun the complete manuscript analysis or its projection
ensemble (a ridge regression and a random forest). The `toy_*` files are synthetic examples.

The PolB phylotype catalogues are supplied with the manuscript (Supplementary Data 1
and 1b), not with this toolkit. Historical upstream database versions cannot be
recovered from it.
