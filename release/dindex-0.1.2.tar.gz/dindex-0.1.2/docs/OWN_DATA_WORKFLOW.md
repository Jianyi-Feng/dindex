# Analyse your own community data

1. Prepare a CSV or TSV abundance table: first column sample ID, remaining columns
   feature IDs. Prepare a taxonomy table with `feature` and `order` (or your chosen
   rank). Use matching, unique feature identifiers and consistent abundance units.
   Missing taxonomy features are ignored and reported; their abundance is excluded
   from the mapped total used in `share`. Select the pair for a biological reason.
2. Compute the index, retaining the QC flags and focal-group abundances:

   ```bash
   dindex compute --abundance examples/data/toy_counts.tsv --taxonomy examples/data/toy_taxonomy.tsv --rank genus --plus Prochlorococcus --minus Synechococcus --counts --min-share 0.2 -o D.tsv
   ```

   Use `--counts` only for genuine counts. For coverage, omit it or use
   `--bootstrap 2000` for descriptive feature-composition sensitivity. Neither
   interval represents biological replication. A low-share flag does not remove a
   sample automatically. Both-zero samples have undefined D; one-sided zeros give ±1.
3. Join environment metadata to D **by sample ID**, not row order, and retain only
   the observations supported by your predeclared QC rule. Inspect the bundled
   `toy_D_env.tsv` for the joined format. This is synthetic data, not evidence for
   a biological relationship. For sensitivity:

   ```bash
   dindex calibrate --table examples/data/toy_D_env.tsv --driver temperature --n-boot 200
   ```

   Use station clusters for repeated spatial sampling or HAC errors for ordered time
   series when appropriate. A zero crossing may be unstable or outside the data range.
4. Fit and save a bounded local calibration with `dindex fit`, then apply it with
   `dindex predict` (README commands). Inspect the JSON's fitted range, sample count
   and exclusions. Predictions include original metadata and a QC flag. Do not train
   on all data and report in-sample agreement as validation. Split entire stations,
   subjects or time blocks as appropriate; evaluate held-out error and bias before
   fitting the final model. Endpoint exclusions can bias calibration when common.
5. Report pair definitions, abundance units, taxonomy/database version, QC threshold,
   exclusions, calibration range, validation design and package version. Retain the
   model JSON and exact input files. See REPORTING_CHECKLIST.md and METHODS_TEMPLATE.md.

The supplied local model is not pretrained on SPOT/Tara. It is not the paper's
multivariate projection ensemble. Absolute abundances, extraction/mapping biases,
causal effects and future community adaptation are not recovered by this index.
