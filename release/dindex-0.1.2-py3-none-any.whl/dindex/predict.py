"""Portable, single-driver log-ratio calibration for new user datasets."""
from __future__ import annotations

import numpy as np
import pandas as pd


def fit_calibration(data: pd.DataFrame, driver: str, d_col: str = "D") -> dict:
    """Fit atanh(D) = intercept + slope * driver; return a JSON-safe model.

    Missing values are omitted. Exact D endpoints are excluded because atanh is
    infinite there; no pseudocount or endpoint replacement is applied. This is a
    descriptive calibration, requiring independent validation before projection.
    """
    values = data[[driver, d_col]].apply(pd.to_numeric, errors="raise")
    if np.isinf(values.to_numpy()).any():
        raise ValueError("calibration values must be finite or missing")
    if ((values[d_col].dropna() < -1) | (values[d_col].dropna() > 1)).any():
        raise ValueError("D must lie in [-1, 1]")
    complete = values.dropna()
    usable = complete[complete[d_col].abs() < 1]
    if len(usable) < 4 or usable[driver].nunique() < 2:
        raise ValueError("need at least four complete interior-D observations and two driver values")
    x = usable[driver].to_numpy(float)
    center = float(x.mean())
    design = np.column_stack([np.ones(len(x)), x - center])
    coef, _, rank, _ = np.linalg.lstsq(design, np.arctanh(usable[d_col].to_numpy(float)), rcond=None)
    if rank != 2:
        raise ValueError("calibration design is rank deficient")
    return {"schema": "dindex.single_driver_logratio.v1", "driver": driver,
            "d_col": d_col, "center": center, "intercept": float(coef[0]),
            "slope": float(coef[1]), "driver_min": float(x.min()), "driver_max": float(x.max()),
            "n_fit": len(usable), "n_missing": len(values) - len(complete),
            "n_endpoints_excluded": len(complete) - len(usable)}


def predict_calibration(model: dict, data: pd.DataFrame) -> pd.DataFrame:
    """Predict bounded D; mark missing driver values and range extrapolation.

    Flags concern only the observed driver range, not ecological transferability.
    Returns point predictions, without prediction intervals or causal inference.
    """
    if model.get("schema") != "dindex.single_driver_logratio.v1":
        raise ValueError("unsupported calibration model schema")
    keys = ["center", "intercept", "slope", "driver_min", "driver_max"]
    if not all(np.isfinite(model[k]) for k in keys) or model["driver_min"] >= model["driver_max"]:
        raise ValueError("invalid calibration model parameters")
    x = pd.to_numeric(data[model["driver"]], errors="raise")
    if np.isinf(x.to_numpy(float)).any():
        raise ValueError("prediction driver must be finite or missing")
    outside = (x < model["driver_min"]) | (x > model["driver_max"])
    result = data.copy()
    result["D_predicted"] = np.tanh(model["intercept"] + model["slope"] * (x - model["center"]))
    result["prediction_qc"] = np.where(x.isna(), "missing_driver", np.where(outside, "extrapolation", "within_driver_range"))
    return result
